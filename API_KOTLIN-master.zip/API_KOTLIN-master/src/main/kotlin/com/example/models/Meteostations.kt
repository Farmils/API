package com.example.models

import kotlinx.coroutines.flow.flowOf
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json

import org.jetbrains.exposed.dao.IntEntity
import org.jetbrains.exposed.dao.IntEntityClass
import org.jetbrains.exposed.dao.id.EntityID
import org.jetbrains.exposed.dao.id.IntIdTable
import org.jetbrains.exposed.sql.Column
import org.jetbrains.exposed.sql.ColumnType
import org.jetbrains.exposed.sql.IColumnType
import org.jetbrains.exposed.sql.Table
import org.jetbrains.exposed.sql.json.json
import org.postgresql.geometric.PGpoint
import org.postgresql.util.PGobject
import kotlin.reflect.KProperty


@Serializable
data class Point(val latitude:String, val longitude:String)

@Serializable
data class Meteostation(
    val station_id:Int,
    val station_coord:String,
    val station_z:String,
    val station_address:String,
    val station_name:String

)
object Meteostations: IntIdTable(columnName = "id"){
    val station_coord = pgpoint("station_coord")
    val station_z=varchar("station_z", length = 255)
    val station_address=varchar("station_address", length = 255)
    val station_name=varchar("station_name", length = 255)

}

class MeteostationMain(id: EntityID<Int>) : IntEntity(id){
    companion object : IntEntityClass<MeteostationMain>(Meteostations)
    val station_coord by Meteostations.station_coord
    val station_z by Meteostations.station_z
    val station_address by Meteostations.station_address
    val station_name by Meteostations.station_name
}

fun Table.pgpoint(name:String) : Column<String> = registerColumn(name, PGpointType())
class PGpointType():ColumnType(){

    override fun sqlType(): String = buildString{
        append("PGpoint")
    }

    override fun valueFromDB(value: Any): Any {
        return (value as PGpoint).value
    }

}
