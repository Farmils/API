package com.example.dao.Meteostations

import com.example.models.Meteostation
import com.example.models.MeteostationMain
import com.example.models.Meteostations

interface MeteostationsDaoFacade {
    suspend fun findByStation(): List<Meteostation>
    suspend fun findByStationName(station_name:String): List<Meteostation>?
    suspend fun findByMeteostationAddress(meteostation_address:String): List<Meteostation>?
}