package com.example.dao.Meteostations

import com.example.dao.DatabaseFactory.dbQuery
import com.example.dao.Measurements.MeasurementsDaoImpl
import com.example.models.*
import org.jetbrains.exposed.sql.ResultRow
import org.jetbrains.exposed.sql.SizedIterable
import org.jetbrains.exposed.sql.SqlExpressionBuilder.eq
import org.jetbrains.exposed.sql.select

class MeteostationsDaoImpl:MeteostationsDaoFacade {
    //private fun resultRowToMeateostations(row: ResultRow) = Meteostation(station_id = row[Meteostations.station_z], station_coord = Point("123", "!23"), station_z = row[Meteostations.station_z], station_address = row[Meteostations.station_address], station_name = row[Meteostations.station_name])

    private fun resultMapper(elem: MeteostationMain) = Meteostation(station_id = elem.id.value, station_coord = elem.station_coord, station_z = elem.station_z, station_name = elem.station_name, station_address = elem.station_address )
    override suspend fun findByStation(): List<Meteostation> = dbQuery {
        MeteostationMain.all().toList().map(::resultMapper)
    }

    override suspend fun findByStationName(station_name: String): List<Meteostation> = dbQuery {
//        Meteostations.select{Meteostations.station_name eq station_name}.map(::resultRowToMeateostations)
        TODO()
    }

    override suspend fun findByMeteostationAddress(meteostation_address: String): List<Meteostation> = dbQuery {
        TODO()
//        Meteostations.select{Meteostations.station_address eq meteostation_address}.map(::resultRowToMeateostations)
    }
}
val meteostationDao= MeteostationsDaoImpl()